// Firebaseの設定(dj-yoteihyo)。この値は公開されても問題ない情報です。データはFirestoreのルールで守られます。
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyBTU2AjvvOKmrXbmIgAatGaiPyHafXsKT0",
  authDomain: "dj-yoteihyo.firebaseapp.com",
  projectId: "dj-yoteihyo",
  storageBucket: "dj-yoteihyo.firebasestorage.app",
  messagingSenderId: "163570833249",
  appId: "1:163570833249:web:68c9c683a4096eae325720"
};
